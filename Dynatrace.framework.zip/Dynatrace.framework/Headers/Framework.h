//
//  Dynatrace-Framework.h
//  Dynatrace-Framework
//
//  Created by Neal T. Leverenz on 11/25/15.
//  Copyright © 2015-2016 Dynatrace LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Dynatrace-Framework.
FOUNDATION_EXPORT double Dynatrace_FrameworkVersionNumber;

//! Project version string for Dynatrace-Framework.
FOUNDATION_EXPORT const unsigned char Dynatrace_FrameworkVersionString[];

// In this header, you should import all the public headers of your framework
#import "Dynatrace.h"
